﻿using GenericBoxOfString;

int stringsToRead = int.Parse(Console.ReadLine());
for (int i = 0; i < stringsToRead; i++)
{
    string str = Console.ReadLine();
    Box<string> box = new Box<string>(str);
    Console.WriteLine(box);
}