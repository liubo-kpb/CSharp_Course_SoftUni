﻿using GenericBoxOfString;

int stringsToRead = int.Parse(Console.ReadLine());
List<Box<int>> strs = new List<Box<int>>();
for (int i = 0; i < stringsToRead; i++)
{
    //string str = Console.ReadLine();
    int str = int.Parse(Console.ReadLine());
    Box<int> box = new Box<int>(str);
    strs.Add(box);
}
Swap(strs);
foreach (Box<int> box in strs)
{
    Console.WriteLine(box);
}

static void Swap<T>(List<T> list)
{
    int[] swapIndexes = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
    T temp = list[swapIndexes[0]];
    list[swapIndexes[0]] = list[swapIndexes[1]];
    list[swapIndexes[1]] = temp;
}
