﻿using System;

namespace GenericBoxOfString
{
    public class Box<T>
    {
        private const int initialSize = 4;
        private T value;

        public Box(T value)
        {
            this.value = value;
        }
        public override string ToString() => $"{typeof(T)}: {value}";
    }
}
