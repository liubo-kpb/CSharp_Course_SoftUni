﻿using GenericBoxOfString;

int stringsToRead = int.Parse(Console.ReadLine());
for (int i = 0; i < stringsToRead; i++)
{
    //string str = Console.ReadLine();
    int str = int.Parse(Console.ReadLine());
    Box<int> box = new Box<int>(str);
    Console.WriteLine(box);
}