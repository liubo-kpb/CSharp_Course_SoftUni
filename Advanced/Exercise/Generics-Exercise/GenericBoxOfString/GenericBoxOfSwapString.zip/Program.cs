﻿using GenericBoxOfString;

int stringsToRead = int.Parse(Console.ReadLine());
List<Box<string>> strs = new List<Box<string>>();
for (int i = 0; i < stringsToRead; i++)
{
    string str = Console.ReadLine();
    //int str = int.Parse(Console.ReadLine());
    Box<string> box = new Box<string>(str);
    strs.Add(box);
}
Swap(strs);
foreach (Box<string> box in strs)
{
    Console.WriteLine(box);
}

static void Swap<T>(List<T> list)
{
    int[] swapIndexes = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
    T temp = list[swapIndexes[0]];
    list[swapIndexes[0]] = list[swapIndexes[1]];
    list[swapIndexes[1]] = temp;
}
