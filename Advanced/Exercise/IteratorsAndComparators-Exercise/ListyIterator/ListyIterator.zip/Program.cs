﻿using ListyIterator;

string input = Console.ReadLine();
ListyIterator<string> listyIterator = null;

listyIterator = new ListyIterator<string>(input.Split().Skip(1).ToArray());

while ((input = Console.ReadLine()) != "END")
{
    switch (input)
    {
        case "Move":
            Console.WriteLine(listyIterator.Move());
            break;
        case "Print":
            try
            {
                listyIterator.Print();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            break;
        case "HasNext":
            Console.WriteLine(listyIterator.HasNext());
            break;
    }
}