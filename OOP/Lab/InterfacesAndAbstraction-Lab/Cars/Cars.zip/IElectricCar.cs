﻿namespace Cars
{
    internal interface IElectricCar
    {
        int Battery { get; }
    }
}
