﻿namespace _08.CollectionHierarchy.Models.Interfaces
{
    internal interface IAddCollection<T>
    {
        public int Add(T item);
    }
}
