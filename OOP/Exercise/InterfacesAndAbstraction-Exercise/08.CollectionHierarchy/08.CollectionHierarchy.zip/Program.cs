﻿namespace _08.CollectionHierarchy
{
    using Core;
    internal class Program
    {
        static void Main(string[] args)
        {
            new Engine();
        }
    }
}
