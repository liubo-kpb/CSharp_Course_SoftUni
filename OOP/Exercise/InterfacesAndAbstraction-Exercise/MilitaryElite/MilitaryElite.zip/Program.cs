﻿namespace MilitaryElite
{
    using Core;
    internal class Program
    {
        static void Main(string[] args)
        {
            new Engine();
        }
    }
}
