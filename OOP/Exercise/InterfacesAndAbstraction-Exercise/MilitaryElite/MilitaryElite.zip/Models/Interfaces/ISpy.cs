﻿namespace MilitaryElite.Models.Interfaces
{
    internal interface ISpy : ISoldier
    {
        public int CodeNumber { get; }
    }
}
