﻿namespace MilitaryElite.Models.Interfaces
{
    internal interface IRepair
    {
        public string PartName { get; }
        public int HoursWorked { get; }
    }
}
