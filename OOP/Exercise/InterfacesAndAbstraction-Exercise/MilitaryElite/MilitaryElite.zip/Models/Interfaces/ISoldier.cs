﻿namespace MilitaryElite.Models.Interfaces
{
    internal interface ISoldier
    {
        public string FirstName { get; }
        public string LastName { get; }
        public string Id { get; }
    }
}
