﻿namespace MilitaryElite.Models.Interfaces
{
    internal interface IPrivate : ISoldier
    {
        public decimal Salary { get; }
    }
}
