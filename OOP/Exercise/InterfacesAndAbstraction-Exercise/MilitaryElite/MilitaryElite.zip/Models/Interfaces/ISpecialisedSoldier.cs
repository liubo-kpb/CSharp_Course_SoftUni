﻿namespace MilitaryElite.Models.Interfaces
{
    internal interface ISpecialisedSoldier : IPrivate
    {
        public string Corps { get; }
    }
}
