﻿namespace Telephony.Model.Interfaces
{
    public interface IStationaryPhone
    {
        string Call(string number);
    }
}
