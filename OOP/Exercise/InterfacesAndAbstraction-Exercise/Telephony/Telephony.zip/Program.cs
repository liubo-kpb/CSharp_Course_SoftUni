﻿namespace Telephony
{
    using Engine;
    public class Program
    {
        static void Main(string[] args)
        {
            new RunApplication();
        }
    }
}
