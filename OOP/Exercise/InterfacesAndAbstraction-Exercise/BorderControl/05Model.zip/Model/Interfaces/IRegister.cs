﻿namespace BorderControl.Model.Interfaces
{
    public interface IRegister
    {
        string Id { get; }
    }
}
