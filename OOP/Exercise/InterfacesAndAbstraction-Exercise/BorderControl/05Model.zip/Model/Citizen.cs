﻿namespace BorderControl.Model
{
    using Interfaces;
    internal class Citizen : ICitizen
    {
        public Citizen(string name, int age, string id, string birthday)
        {
            Name = name;
            Age = age;
            Id = id;
            Birthday = birthday;
        }
        
        public Citizen(string name, int age, string id)
        {
            Name = name;
            Age = age;
            Id = id;
            Birthday = "We're only looking for intruders at this time. Birthdays are not a priority. Move along!";
        }

        public string Name { get; private set; }

        public int Age { get; private set; }

        public string Id { get; private set; }

        public string Birthday { get; private set; }
    }
}
