﻿namespace BorderControl
{
    using System;
    using System.Collections.Generic;

    using Model;
    using Model.Interfaces;

    internal class Engine
    {
        private List<IRegister> visitors;
        private List<IBiological> biologicalVisitors;

        public Engine()
        {
            Run();
        }

        private void Run()
        {
            //RegisterVisitors();
            RegisterVisitorsBC();

            string searchByString = Console.ReadLine();
            
            //FindAndPrintIntrudors(searchByString);
            FindAndPrintVisitorsWithSameBirthdays(searchByString);
        }

        private void FindAndPrintVisitorsWithSameBirthdays(string birthyear)
        {
            foreach (var biological in biologicalVisitors)
            { 
                if (biological.Birthday.EndsWith(birthyear))
                {
                    Console.WriteLine(biological.Birthday);
                }
            }
        }

        private void RegisterVisitorsBC()
        {
            biologicalVisitors = new List<IBiological>();
            string input = string.Empty;
            while ((input = Console.ReadLine()) != "End")
            {
                string[] inputDetails = input.Split();
                string visitor = inputDetails[0];

                if (visitor == "Citizen")
                {
                    string name = inputDetails[1];
                    int age = int.Parse(inputDetails[2]);
                    string id = inputDetails[3];
                    string birthday = inputDetails[4];

                    Citizen citizen = new Citizen(name, age, id, birthday);
                    biologicalVisitors.Add(citizen);
                }
                else if (visitor == "Robot")
                {
                    continue;
                }
                else if (visitor == "Pet")
                {
                    string name = inputDetails[1];
                    string birthday = inputDetails[2];

                    Pet pet = new Pet(name, birthday);
                    biologicalVisitors.Add(pet);
                }
            }
        }

        private void FindAndPrintIntrudors(string fakeID)
        {
            foreach (var citizen in visitors)
            {
                if (citizen.Id.EndsWith(fakeID))
                {
                    Console.WriteLine(citizen.Id);
                }
            }
        }

        private void RegisterVisitors()
        {
            visitors = new List<IRegister>();
            string input = string.Empty;
            while ((input = Console.ReadLine()) != "End")
            {
                string[] inputDetails = input.Split();

                if (inputDetails.Length == 3)
                {
                    string name = inputDetails[0];
                    int age = int.Parse(inputDetails[1]);
                    string id = inputDetails[2];

                    Citizen citizen = new Citizen(name, age, id);
                    visitors.Add(citizen);
                }
                else if (inputDetails.Length == 2)
                {
                    string model = inputDetails[0];
                    string id = inputDetails[1];

                    Robot robot = new Robot(model, id);
                    visitors.Add(robot);
                }
            }
        }
    }
}
