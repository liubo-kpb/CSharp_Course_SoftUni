﻿namespace BorderControl
{
    internal class Program
    {
        static void Main(string[] args)
        {
            new Engine();
        }
    }
}
