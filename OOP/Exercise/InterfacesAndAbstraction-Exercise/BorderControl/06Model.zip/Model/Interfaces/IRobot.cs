﻿namespace BorderControl.Model.Interfaces
{
    public interface IRobot : IRegister
    {
        string Model { get; }
    }
}
