﻿namespace BorderControl.Model.Interfaces
{
    public interface ICitizen : IRegister
    {
        string Name { get; }
        int Age { get; }
    }
}
