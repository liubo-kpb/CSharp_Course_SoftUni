﻿namespace BorderControl
{
    using BorderControl.Model;
    using BorderControl.Model.Interfaces;
    using System;
    using System.Collections.Generic;

    internal class Engine
    {
        private List<IRegister> visitors;
        public Engine()
        {
            visitors = new List<IRegister>();
            Run();
        }

        private void Run()
        {
            RegisterVisitors();

            string fakeID = Console.ReadLine();
            FindAndPrintIntrudors(fakeID);
        }

        private void FindAndPrintIntrudors(string fakeID)
        {
            foreach (var citizen in visitors)
            {
                if (citizen.Id.EndsWith(fakeID))
                {
                    Console.WriteLine(citizen.Id);
                }
            }
        }

        private void RegisterVisitors()
        {
            string input = string.Empty;
            while ((input = Console.ReadLine()) != "End")
            {
                string[] inputDetails = input.Split();

                if (inputDetails.Length == 3)
                {
                    string name = inputDetails[0];
                    int age = int.Parse(inputDetails[1]);
                    string id = inputDetails[2];

                    Citizen citizen = new Citizen(name, age, id);
                    visitors.Add(citizen);
                }
                else if (inputDetails.Length == 2)
                {
                    string model = inputDetails[0];
                    string id = inputDetails[1];

                    Robot robot = new Robot(model, id);
                    visitors.Add(robot);
                }
            }
        }
    }
}
